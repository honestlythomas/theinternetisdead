# Dead David TTS

Standalone Chromium/Edge text-to-speech extension extracted from theinternetisdead extension suite.

## Install unpacked

1. Open `edge://extensions` or `chrome://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked**.
4. Select the `dead-david-tts` folder.
5. Refresh any already-open webpages once.

Select text on a webpage to reveal the floating reader controls. The popup lets you enable or disable the reader, choose a voice, adjust rate and pitch, enable word highlighting, read the current selection, or stop speech.

Microsoft David is preferred when installed. Otherwise the browser uses the closest available voice.


## Custom Selection Colors

Enable the popup checkbox to use a lime-green selection background with dark-purple selected text across webpages.

## Version 1.1.6

Optimized live word highlighting by caching the selected text-node map and limiting highlight repaints to one per animation frame.

- Selection controls remain invisible until the pointer hovers the selected text.
- Shift+Space stops active reading and does nothing when idle.


### Shift+Space controls
- When idle: reads the currently selected text.
- While speaking: pauses the current reading.
- While paused: resumes from the same position.


## v1.1.6
- Combined the selection popup play and stop controls into one button.
- The button shows Play while idle and Stop while speech is active or paused.
- Shift+Space still plays, pauses, and resumes selected text.
