(() => {
  if (window.__deadDavidTtsLoaded) return;
  window.__deadDavidTtsLoaded = true;

  const DEFAULT_SETTINGS = {
    readerEnabled: true,
    readerVoice: "Microsoft David",
    readerRate: 100,
    readerPitch: 100,
    readerHighlightWords: true,
    customSelectionColors: false
  };

  let selectedText = "";
  let lastSelectedText = "";
  let hideTimer = null;
  let savedControlPosition = null;
  let dragState = null;
  let suppressNextClick = false;
  let activeSelectionRange = null;
  let activeSelectionText = "";
  let activeSelectionSegments = [];
  let activeSpeechOffsetBase = 0;
  let activeUtterance = null;
  let highlightFrame = 0;
  let pendingHighlight = null;
  let selectionHoverRects = [];
  let lastPointerPosition = null;
  let hoverFrame = 0;
  let activeSnapTarget = null;


  const POSITION_STORAGE_KEY = "deadDavidTtsControlPosition";
  const READ_HIGHLIGHT_NAME = "ms-david-reader-read-so-far";
  const CURRENT_HIGHLIGHT_NAME = "ms-david-reader-current-word";
  const STYLE_ID = "dead-david-tts-style";
  const CUSTOM_SELECTION_STYLE_ID = "dead-david-custom-selection-style";
  const SNAP_OVERLAY_ID = "dead-david-snap-overlay";
  const SNAP_TARGET_ID = "dead-david-snap-target";
  const SNAP_THRESHOLD = 110;
  const SNAP_MARGIN = 14;

  function ensureReaderStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #ms-david-selection-reader-controls {
        position: fixed;
        z-index: 2147483647;
        display: none;
        align-items: center;
        gap: 0;
        padding: 8px;
        border: 2px solid #99ff00;
        border-radius: 999px;
        background: rgba(26, 0, 38, 0.94);
        box-shadow: 0 0 12px rgba(153, 255, 0, 0.35), 0 0 22px rgba(128, 0, 255, 0.22);
        font-family: Courier New, monospace;
        pointer-events: auto;
        user-select: none;
        backdrop-filter: blur(3px);
        opacity: 0;
        visibility: visible;
        transition: opacity 120ms ease, visibility 120ms ease, width 160ms ease;
        cursor: move;
      }

      #ms-david-selection-reader-controls.is-visible {
        display: inline-flex;
      }

      #ms-david-selection-reader-controls.is-hover-revealed,
      #ms-david-selection-reader-controls:hover,
      #ms-david-selection-reader-controls.is-dragging {
        opacity: 1;
        visibility: visible;
        pointer-events: auto;
      }

      .ms-david-reader-button {
        position: relative;
        z-index: 1;
        width: 48px;
        height: 48px;
        border: 2px solid rgba(153, 255, 0, 0.55);
        border-radius: 999px;
        background: rgba(75, 0, 118, 0.85);
        color: #99ff00;
        font: 700 28px/1 Courier New, monospace;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }

      .ms-david-reader-button:hover {
        background: rgba(153, 255, 0, 0.18);
        border-color: #99ff00;
        box-shadow: 0 0 10px rgba(153, 255, 0, 0.35);
      }

      #ms-david-selection-reader-controls .ms-david-reader-button + .ms-david-reader-button {
        width: 0;
        min-width: 0;
        margin-left: 0;
        padding: 0;
        border-width: 0;
        opacity: 0;
        transform: translateX(-12px) scale(0.92);
        overflow: hidden;
        pointer-events: none;
        transition: width 180ms ease, margin-left 180ms ease, opacity 140ms ease, transform 180ms ease, border-width 180ms ease;
      }

      #ms-david-selection-reader-controls:hover .ms-david-reader-button + .ms-david-reader-button,
      #ms-david-selection-reader-controls.is-dragging .ms-david-reader-button + .ms-david-reader-button {
        width: 48px;
        margin-left: 8px;
        border-width: 2px;
        opacity: 1;
        transform: translateX(0) scale(1);
        pointer-events: auto;
      }



      #dead-david-snap-overlay {
        position: fixed;
        inset: 0;
        z-index: 2147483644;
        display: none;
        background: rgba(75, 0, 130, 0.25);
        pointer-events: none;
      }

      #dead-david-snap-overlay.is-active {
        display: block;
      }

      #dead-david-snap-target {
        position: fixed;
        z-index: 2147483646;
        display: none;
        box-sizing: border-box;
        border: 5px dashed #99ff00;
        background: transparent;
        pointer-events: none;
      }

      #dead-david-snap-target.is-active {
        display: block;
      }

      ::highlight(ms-david-reader-read-so-far) {
        color: #99ff00;
        background: rgba(153, 255, 0, 0.16);
      }

      ::highlight(ms-david-reader-current-word) {
        color: #99ff00;
        background: #000000;
      }
    `;
    document.documentElement.appendChild(style);
  }

  ensureReaderStyle();

  function applyCustomSelectionColors(enabled) {
    let style = document.getElementById(CUSTOM_SELECTION_STYLE_ID);

    if (!enabled) {
      style?.remove();
      return;
    }

    if (!style) {
      style = document.createElement("style");
      style.id = CUSTOM_SELECTION_STYLE_ID;
      style.textContent = `
        ::selection {
          background: #99ff00 !important;
          color: #260033 !important;
          font-family: "Courier New", Courier, monospace !important;
          font-weight: 700 !important;
          text-shadow: none !important;
        }

        ::-moz-selection {
          background: #99ff00 !important;
          color: #260033 !important;
          font-family: "Courier New", Courier, monospace !important;
          font-weight: 700 !important;
          text-shadow: none !important;
        }
      `;
      document.documentElement.appendChild(style);
    }
  }

  chrome.storage.local.get(DEFAULT_SETTINGS, (items) => {
    applyCustomSelectionColors(Boolean(items.customSelectionColors));
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    if (changes.customSelectionColors) {
      applyCustomSelectionColors(Boolean(changes.customSelectionColors.newValue));
    }

    if (changes.readerEnabled?.newValue === false) {
      speechSynthesis.cancel();
      activeUtterance = null;
      clearReadingHighlights();
      hideControls();
    }
  });

  const controls = document.createElement("div");
  controls.id = "ms-david-selection-reader-controls";
  controls.setAttribute("role", "toolbar");
  controls.setAttribute("aria-label", "Dead David TTS selection controls");

  const playButton = document.createElement("button");
  playButton.className = "ms-david-reader-button";
  playButton.type = "button";
  playButton.title = "Read selected text";
  playButton.setAttribute("aria-label", "Read selected text");
  playButton.textContent = "▶";

  controls.append(playButton);
  document.documentElement.appendChild(controls);

  const snapOverlay = document.createElement("div");
  snapOverlay.id = SNAP_OVERLAY_ID;
  document.documentElement.appendChild(snapOverlay);

  const snapTarget = document.createElement("div");
  snapTarget.id = SNAP_TARGET_ID;
  document.documentElement.appendChild(snapTarget);

  chrome.storage.local.get({ [POSITION_STORAGE_KEY]: null }, (items) => {
    const position = items?.[POSITION_STORAGE_KEY];
    if (position && Number.isFinite(position.left) && Number.isFinite(position.top)) {
      savedControlPosition = position;
    }
  });

  function getSelectionText({ trim = true } = {}) {
    const text = String(window.getSelection?.()?.toString() || "");
    return trim ? text.trim() : text;
  }

  function clearReadingHighlights() {
    if (highlightFrame) {
      cancelAnimationFrame(highlightFrame);
      highlightFrame = 0;
    }
    pendingHighlight = null;

    try {
      CSS?.highlights?.delete(READ_HIGHLIGHT_NAME);
      CSS?.highlights?.delete(CURRENT_HIGHLIGHT_NAME);
    } catch {
      // CSS Highlights are Chromium/Edge-era magic. If missing, speech still works.
    }
  }

  function rememberSelectionRange() {
    const selection = window.getSelection?.();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return;

    activeSelectionRange = selection.getRangeAt(0).cloneRange();
    activeSelectionText = selection.toString();
    activeSelectionSegments = getTextSegmentsInRange(activeSelectionRange);
    refreshSelectionHoverRects();
    clearReadingHighlights();
  }

  function getTextSegmentsInRange(range) {
    const segments = [];
    const root = range.commonAncestorContainer;
    const walkerRoot = root.nodeType === Node.TEXT_NODE ? root.parentNode : root;
    if (!walkerRoot) return segments;

    const walker = document.createTreeWalker(walkerRoot, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
        return range.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });

    let absoluteStart = 0;
    let node;
    while ((node = walker.nextNode())) {
      let start = 0;
      let end = node.nodeValue.length;

      if (node === range.startContainer) start = range.startOffset;
      if (node === range.endContainer) end = range.endOffset;
      if (end <= start) continue;

      const length = end - start;
      segments.push({ node, start, end, absoluteStart, absoluteEnd: absoluteStart + length });
      absoluteStart += length;
    }

    return segments;
  }

  function makeRangesForOffsets(range, startOffset, endOffset) {
    if (!range || !CSS?.highlights || endOffset <= startOffset) return [];

    const segments = range === activeSelectionRange && activeSelectionSegments.length
      ? activeSelectionSegments
      : getTextSegmentsInRange(range);
    const ranges = [];

    for (const segment of segments) {
      const localStartAbsolute = Math.max(startOffset, segment.absoluteStart);
      const localEndAbsolute = Math.min(endOffset, segment.absoluteEnd);
      if (localEndAbsolute <= localStartAbsolute) continue;

      const highlightRange = document.createRange();
      highlightRange.setStart(segment.node, segment.start + (localStartAbsolute - segment.absoluteStart));
      highlightRange.setEnd(segment.node, segment.start + (localEndAbsolute - segment.absoluteStart));
      ranges.push(highlightRange);
    }

    return ranges;
  }

  function expandCurrentWordOffsets(text, charIndex, charLength) {
    const safeIndex = Math.max(0, Math.min(text.length, activeSpeechOffsetBase + (Number(charIndex) || 0)));
    let start = safeIndex;
    let end = Math.max(start + 1, start + (Number(charLength) || 0));

    while (start > 0 && !/\s/.test(text[start - 1])) start -= 1;
    while (end < text.length && !/\s/.test(text[end])) end += 1;

    return { start, end: Math.min(text.length, end) };
  }

  function paintReadingHighlights(charIndex = 0, charLength = 0) {
    if (!activeSelectionRange || !CSS?.highlights) return;

    const text = activeSelectionText || activeSelectionRange.toString();
    if (!text) return;

    const word = expandCurrentWordOffsets(text, charIndex, charLength);
    const readEnd = Math.max(
      word.end,
      Math.min(text.length, activeSpeechOffsetBase + (Number(charIndex) || 0) + (Number(charLength) || 0))
    );

    const readRanges = makeRangesForOffsets(activeSelectionRange, 0, readEnd);
    const currentRanges = makeRangesForOffsets(activeSelectionRange, word.start, word.end);

    if (readRanges.length) CSS.highlights.set(READ_HIGHLIGHT_NAME, new Highlight(...readRanges));
    else CSS.highlights.delete(READ_HIGHLIGHT_NAME);

    if (currentRanges.length) CSS.highlights.set(CURRENT_HIGHLIGHT_NAME, new Highlight(...currentRanges));
    else CSS.highlights.delete(CURRENT_HIGHLIGHT_NAME);
  }

  function updateReadingHighlights(charIndex = 0, charLength = 0) {
    pendingHighlight = { charIndex, charLength };
    if (highlightFrame) return;

    highlightFrame = requestAnimationFrame(() => {
      highlightFrame = 0;
      const next = pendingHighlight;
      pendingHighlight = null;
      if (next) paintReadingHighlights(next.charIndex, next.charLength);
    });
  }

  function refreshSelectionHoverRects() {
    let range = null;
    const selection = window.getSelection?.();

    if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
      range = selection.getRangeAt(0);
    } else if (activeSelectionRange) {
      range = activeSelectionRange;
    }

    if (!range) {
      selectionHoverRects = [];
      return;
    }

    try {
      selectionHoverRects = Array.from(range.getClientRects())
        .filter((rect) => rect.width > 0 && rect.height > 0)
        .map((rect) => ({
          left: rect.left,
          right: rect.right,
          top: rect.top,
          bottom: rect.bottom
        }));
    } catch {
      selectionHoverRects = [];
    }
  }

  function pointerIsOverSelection(x, y) {
    return selectionHoverRects.some((rect) =>
      x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom
    );
  }

  function updateControlHoverVisibility() {
    const overSelection = lastPointerPosition &&
      pointerIsOverSelection(lastPointerPosition.x, lastPointerPosition.y);
    const overControls = controls.matches(":hover");

    controls.classList.toggle("is-hover-revealed", Boolean(overSelection || overControls || dragState));
  }

  function getSelectionRect() {
    refreshSelectionHoverRects();
    return selectionHoverRects[0] || null;
  }

  function getSnapTargets() {
    const width = controls.offsetWidth || 68;
    const height = controls.offsetHeight || 68;
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const left = SNAP_MARGIN;
    const right = Math.max(SNAP_MARGIN, viewportWidth - width - SNAP_MARGIN);
    const top = SNAP_MARGIN;
    const bottom = Math.max(SNAP_MARGIN, viewportHeight - height - SNAP_MARGIN);
    const centerLeft = Math.max(SNAP_MARGIN, (viewportWidth - width) / 2);
    const centerTop = Math.max(SNAP_MARGIN, (viewportHeight - height) / 2);

    return [
      { id: "top-left", left, top },
      { id: "top-center", left: centerLeft, top },
      { id: "top-right", left: right, top },
      { id: "middle-left", left, top: centerTop },
      { id: "middle-right", left: right, top: centerTop },
      { id: "bottom-left", left, top: bottom },
      { id: "bottom-center", left: centerLeft, top: bottom },
      { id: "bottom-right", left: right, top: bottom }
    ].map((target) => ({
      ...target,
      centerX: target.left + width / 2,
      centerY: target.top + height / 2,
      width,
      height
    }));
  }

  function findNearbySnapTarget(left, top) {
    const width = controls.offsetWidth || 68;
    const height = controls.offsetHeight || 68;
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    let nearest = null;
    let nearestDistance = Infinity;

    for (const target of getSnapTargets()) {
      const distance = Math.hypot(centerX - target.centerX, centerY - target.centerY);
      if (distance < nearestDistance) {
        nearest = target;
        nearestDistance = distance;
      }
    }

    return nearestDistance <= SNAP_THRESHOLD ? nearest : null;
  }

  function showSnapTarget(target) {
    activeSnapTarget = target;
    if (!target) {
      snapOverlay.classList.remove("is-active");
      snapTarget.classList.remove("is-active");
      return;
    }

    const outlinePadding = 8;
    snapTarget.style.left = `${Math.max(0, target.left - outlinePadding)}px`;
    snapTarget.style.top = `${Math.max(0, target.top - outlinePadding)}px`;
    snapTarget.style.width = `${target.width + outlinePadding * 2}px`;
    snapTarget.style.height = `${target.height + outlinePadding * 2}px`;
    snapOverlay.classList.add("is-active");
    snapTarget.classList.add("is-active");
  }

  function hideSnapTarget() {
    activeSnapTarget = null;
    snapOverlay.classList.remove("is-active");
    snapTarget.classList.remove("is-active");
  }

  function clampControlPosition(left, top) {
    const width = controls.offsetWidth || 72;
    const height = controls.offsetHeight || 36;

    return {
      left: Math.max(8, Math.min(window.innerWidth - width - 8, left)),
      top: Math.max(8, Math.min(window.innerHeight - height - 8, top))
    };
  }

  function applyControlPosition(left, top) {
    const position = clampControlPosition(left, top);
    controls.style.left = `${position.left}px`;
    controls.style.top = `${position.top}px`;
    return position;
  }

  function positionControls() {
    const rect = getSelectionRect();
    if (!rect) {
      if (isSpeechActive()) {
        keepControlsVisibleDuringSpeech();
        return;
      }
      return hideControls();
    }

    controls.classList.add("is-visible");

    if (savedControlPosition) {
      applyControlPosition(savedControlPosition.left, savedControlPosition.top);
      return;
    }

    const left = Math.max(8, Math.min(window.innerWidth - 72, rect.left));
    const top = Math.max(8, rect.top - 40);
    applyControlPosition(left, top);
    updateControlHoverVisibility();
  }

  function keepControlsVisibleDuringSpeech() {
    controls.classList.add("is-visible");
    refreshSelectionHoverRects();
    updateControlHoverVisibility();

    if (savedControlPosition) {
      applyControlPosition(savedControlPosition.left, savedControlPosition.top);
      return;
    }

    const rect = controls.getBoundingClientRect();
    if (rect.width || rect.height) {
      applyControlPosition(rect.left || 8, rect.top || 8);
      return;
    }

    applyControlPosition(8, 8);
  }

  function hideControls() {
    controls.classList.remove("is-visible", "is-hover-revealed");
    selectionHoverRects = [];
    hideSnapTarget();
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
  }

  function isSpeechActive() {
    return Boolean(activeUtterance) || speechSynthesis.speaking || speechSynthesis.pending;
  }

  async function getSettings() {
    try {
      const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
      return {
        enabled: Boolean(settings.readerEnabled),
        voiceName: settings.readerVoice || "Microsoft David",
        rate: Number(settings.readerRate || 100) / 100,
        pitch: Number(settings.readerPitch || 100) / 100,
        volume: 1,
        highlightWords: Boolean(settings.readerHighlightWords)
      };
    } catch {
      return {
        enabled: true,
        voiceName: "Microsoft David",
        rate: 1,
        pitch: 1,
        volume: 1,
        highlightWords: true
      };
    }
  }

  async function updateFromSelection() {
    const settings = await getSettings();
    if (!settings.enabled) {
      hideControls();
      clearReadingHighlights();
      return;
    }

    const rawText = getSelectionText({ trim: false });
    const text = rawText.trim();

    if (!text) {
      selectedText = "";

      if (isSpeechActive()) {
        keepControlsVisibleDuringSpeech();
      } else {
        hideControls();
        activeSelectionRange = null;
        activeSelectionText = "";
        activeSelectionSegments = [];
        selectionHoverRects = [];
        clearReadingHighlights();
      }

      return;
    }

    selectedText = text;
    lastSelectedText = text;
    rememberSelectionRange();
    positionControls();
    scheduleHide();
  }

  function getVoicesWhenReady() {
    return new Promise((resolve) => {
      const voices = speechSynthesis.getVoices();
      if (voices.length) return resolve(voices);

      const timeout = setTimeout(() => resolve(speechSynthesis.getVoices()), 500);
      speechSynthesis.onvoiceschanged = () => {
        clearTimeout(timeout);
        resolve(speechSynthesis.getVoices());
      };
    });
  }

  async function speak(text) {
    const settings = await getSettings();
    if (!settings.enabled) return;

    const selectionNow = getSelectionText({ trim: false });
    const rawText = String(text || selectionNow || selectedText || lastSelectedText || "");
    const cleanText = rawText.trim();
    if (!cleanText) return;

    activeSpeechOffsetBase = rawText.length - rawText.trimStart().length;
    if (selectionNow.trim()) rememberSelectionRange();

    const voices = await getVoicesWhenReady();
    const preferredVoice = voices.find((voice) =>
      voice.name.toLowerCase().includes(String(settings.voiceName || "Microsoft David").toLowerCase())
    ) || voices.find((voice) => voice.name.toLowerCase().includes("david")) || voices[0];

    speechSynthesis.cancel();
    clearReadingHighlights();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.rate = Number(settings.rate) || 1;
    utterance.pitch = Number(settings.pitch) || 1;
    utterance.volume = Number(settings.volume) || 1;

    activeUtterance = utterance;

    utterance.onstart = () => {
      playButton.textContent = "■";
      playButton.title = "Stop reading";
      playButton.setAttribute("aria-label", "Stop reading");
      keepControlsVisibleDuringSpeech();
      if (settings.highlightWords) updateReadingHighlights(0, 0);
    };

    utterance.onboundary = (event) => {
      if (!settings.highlightWords) return;
      if (event.name === "word" || typeof event.charIndex === "number") {
        updateReadingHighlights(event.charIndex || 0, event.charLength || 0);
      }
    };

    utterance.onend = () => {
      if (settings.highlightWords) updateReadingHighlights(cleanText.length, 0);
      activeUtterance = null;
      playButton.textContent = "▶";
      playButton.title = "Read selected text";
      playButton.setAttribute("aria-label", "Read selected text");
      if (!getSelectionText()) hideControls();
    };

    utterance.onerror = () => {
      activeUtterance = null;
      playButton.textContent = "▶";
      playButton.title = "Read selected text";
      playButton.setAttribute("aria-label", "Read selected text");
      if (!getSelectionText()) hideControls();
    };

    speechSynthesis.speak(utterance);
  }

  function pauseReading() {
    if (!speechSynthesis.speaking || speechSynthesis.paused) return;
    speechSynthesis.pause();
    playButton.textContent = "■";
    playButton.title = "Stop reading";
    playButton.setAttribute("aria-label", "Stop reading");
    keepControlsVisibleDuringSpeech();
  }

  function resumeReading() {
    if (!speechSynthesis.paused) return;
    speechSynthesis.resume();
    playButton.textContent = "■";
    playButton.title = "Stop reading";
    playButton.setAttribute("aria-label", "Stop reading");
    keepControlsVisibleDuringSpeech();
  }

  function toggleReading() {
    if (speechSynthesis.paused) {
      resumeReading();
      return;
    }

    if (speechSynthesis.speaking || speechSynthesis.pending || activeUtterance) {
      pauseReading();
      return;
    }

    const text = getSelectionText() || selectedText || lastSelectedText;
    if (text) speak(text);
  }

  function stop() {
    speechSynthesis.cancel();
    activeUtterance = null;
    playButton.textContent = "▶";
    playButton.title = "Read selected text";
    playButton.setAttribute("aria-label", "Read selected text");
    clearReadingHighlights();
    if (!getSelectionText()) hideControls();
  }

  function saveDraggedPosition(left, top) {
    savedControlPosition = applyControlPosition(left, top);
    chrome.storage.local.set({ [POSITION_STORAGE_KEY]: savedControlPosition });
  }

  function startDragging(event) {
    if (event.button !== 0) return;

    const rect = controls.getBoundingClientRect();
    dragState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top,
      didDrag: false
    };

    controls.setPointerCapture?.(event.pointerId);
  }

  function dragControls(event) {
    if (!dragState || dragState.pointerId !== event.pointerId) return;

    const moved = Math.hypot(event.clientX - dragState.startX, event.clientY - dragState.startY);
    if (moved > 3) {
      dragState.didDrag = true;
      controls.classList.add("is-dragging");
      clearTimeout(hideTimer);
      const nextLeft = event.clientX - dragState.offsetX;
      const nextTop = event.clientY - dragState.offsetY;
      const position = applyControlPosition(nextLeft, nextTop);
      showSnapTarget(findNearbySnapTarget(position.left, position.top));
      event.preventDefault();
    }
  }

  function stopDragging(event) {
    if (!dragState || dragState.pointerId !== event.pointerId) return;

    if (dragState.didDrag) {
      const nextLeft = event.clientX - dragState.offsetX;
      const nextTop = event.clientY - dragState.offsetY;
      const freePosition = clampControlPosition(nextLeft, nextTop);
      const target = activeSnapTarget || findNearbySnapTarget(freePosition.left, freePosition.top);
      if (target) saveDraggedPosition(target.left, target.top);
      else saveDraggedPosition(freePosition.left, freePosition.top);
      suppressNextClick = true;
      setTimeout(() => {
        suppressNextClick = false;
      }, 0);
    }

    controls.releasePointerCapture?.(event.pointerId);
    controls.classList.remove("is-dragging");
    dragState = null;
    hideSnapTarget();
    scheduleHide();
  }

  playButton.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    startDragging(event);
  });


  playButton.addEventListener("mousedown", (event) => event.preventDefault());

  controls.addEventListener("pointerdown", startDragging);
  controls.addEventListener("pointermove", dragControls);
  controls.addEventListener("pointerup", stopDragging);
  controls.addEventListener("pointercancel", stopDragging);

  playButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (suppressNextClick) return;
    if (isSpeechActive() || speechSynthesis.paused) {
      stop();
    } else {
      const text = getSelectionText() || selectedText || lastSelectedText;
      if (text) speak(text);
    }
  });

  controls.addEventListener("mouseenter", () => {
    clearTimeout(hideTimer);
    controls.classList.add("is-hover-revealed");
  });

  controls.addEventListener("mouseleave", () => {
    updateControlHoverVisibility();
    scheduleHide();
  });

  document.addEventListener("mousemove", (event) => {
    lastPointerPosition = { x: event.clientX, y: event.clientY };
    if (hoverFrame) return;

    hoverFrame = requestAnimationFrame(() => {
      hoverFrame = 0;
      if (controls.classList.contains("is-visible")) updateControlHoverVisibility();
    });
  }, { passive: true });

  document.addEventListener("keydown", (event) => {
    if (!event.shiftKey || event.code !== "Space" || event.repeat) return;

    const hasReadableSelection = Boolean(getSelectionText() || selectedText || lastSelectedText);
    if (!isSpeechActive() && !speechSynthesis.paused && !hasReadableSelection) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    toggleReading();
  }, true);

  document.addEventListener("selectionchange", () => {
    window.requestAnimationFrame(updateFromSelection);
  });

  document.addEventListener("mouseup", () => {
    window.requestAnimationFrame(updateFromSelection);
  });

  document.addEventListener("keyup", (event) => {
    if (event.key === "Escape") hideControls();
    window.requestAnimationFrame(updateFromSelection);
  });

  window.addEventListener("scroll", () => {
    if (controls.classList.contains("is-visible")) {
      positionControls();
      updateControlHoverVisibility();
    }
  }, { passive: true });

  window.addEventListener("resize", () => {
    hideSnapTarget();
    if (controls.classList.contains("is-visible")) positionControls();
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || typeof message !== "object") return;

    if (message.type === "DEAD_DAVID_TTS_ACTION") {
      if (message.action === "speak-text") speak(message.text || "");
      if (message.action === "speak-selection") speak(getSelectionText() || selectedText || lastSelectedText);
      if (message.action === "stop") stop();
    }
  });
})();
