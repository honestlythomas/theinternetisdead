const DEFAULTS = {
  readerEnabled: true,
  readerVoice: "Microsoft David",
  readerRate: 100,
  readerPitch: 100,
  readerHighlightWords: true,
  customSelectionColors: false
};

const $ = (id) => document.getElementById(id);
let settings = { ...DEFAULTS };

function setStatus(text) {
  $("status").textContent = text;
}

function render() {
  $("readerToggle").textContent = settings.readerEnabled ? "Disable Reader" : "Enable Reader";
  $("readerVoice").value = settings.readerVoice || "";
  $("readerRate").value = Number(settings.readerRate || 100);
  $("readerPitch").value = Number(settings.readerPitch || 100);
  $("readerRateValue").textContent = `${$("readerRate").value}%`;
  $("readerPitchValue").textContent = `${$("readerPitch").value}%`;
  $("readerHighlightWords").checked = Boolean(settings.readerHighlightWords);
  $("customSelectionColors").checked = Boolean(settings.customSelectionColors);

  const disabled = !settings.readerEnabled;
  $("readerPlay").disabled = disabled;
  $("readerStop").disabled = disabled;
}

async function save(patch) {
  settings = { ...settings, ...patch };
  await chrome.storage.local.set(patch);
  render();
}

function loadVoices() {
  const select = $("readerVoice");
  const voices = speechSynthesis.getVoices();
  const names = [...new Set(voices.map((voice) => voice.name))].sort((a, b) => a.localeCompare(b));

  select.replaceChildren();
  const defaultOption = new Option("Browser default", "");
  select.add(defaultOption);

  if (!names.includes("Microsoft David")) {
    select.add(new Option("Microsoft David (preferred)", "Microsoft David"));
  }

  for (const name of names) select.add(new Option(name, name));
  select.value = settings.readerVoice || "";
}

async function sendReader(action) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus("No active tab found. Somehow the browser misplaced the browser.");
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, {
      type: "DEAD_DAVID_TTS_ACTION",
      action
    });
    setStatus(action === "stop" ? "Speech stopped." : "Reading the selected text.");
  } catch {
    setStatus("This page blocks extensions, or it needs one refresh after installation.");
  }
}

async function init() {
  settings = await chrome.storage.local.get(DEFAULTS);
  loadVoices();
  speechSynthesis.addEventListener?.("voiceschanged", loadVoices);
  speechSynthesis.onvoiceschanged = loadVoices;
  render();

  $("readerToggle").addEventListener("click", () => save({ readerEnabled: !settings.readerEnabled }));
  $("customSelectionColors").addEventListener("change", () => save({ customSelectionColors: $("customSelectionColors").checked }));
  $("readerVoice").addEventListener("change", () => save({ readerVoice: $("readerVoice").value }));
  $("readerRate").addEventListener("input", () => {
    $("readerRateValue").textContent = `${$("readerRate").value}%`;
  });
  $("readerRate").addEventListener("change", () => save({ readerRate: Number($("readerRate").value) }));
  $("readerPitch").addEventListener("input", () => {
    $("readerPitchValue").textContent = `${$("readerPitch").value}%`;
  });
  $("readerPitch").addEventListener("change", () => save({ readerPitch: Number($("readerPitch").value) }));
  $("readerHighlightWords").addEventListener("change", () => save({ readerHighlightWords: $("readerHighlightWords").checked }));
  $("readerPlay").addEventListener("click", () => sendReader("speak-selection"));
  $("readerStop").addEventListener("click", () => sendReader("stop"));
}

init();
